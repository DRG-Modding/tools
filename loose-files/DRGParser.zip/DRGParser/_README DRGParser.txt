- This tool will give you a readable (not in hex) .json file from a pair of .uexp and .uasset files. 
  It's a must have to know the contents of the files, specially if you want to change a value but don’t 
  know exactly what you are looking for.
  
- Check the modding guide for a tutorial.
  
- You need to install this so it works (.NET Core 3.1) https://dotnet.microsoft.com/download/dotnet-core/thank-you/runtime-desktop-3.1.8-windows-x64-installer

- Made by @Approved.