- Just the fonts from the game for whatever you need them

- Thanks to GoldBl4d3 for providing them.
